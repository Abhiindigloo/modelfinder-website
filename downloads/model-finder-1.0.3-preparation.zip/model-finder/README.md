# Model Finder 1.0.3

Publisher selected: Indigloo (business verification pending). Skills for cross-provider model research, evaluation planning, and careful interpretation of user-supplied usage and model-size estimates.

Companion website: https://abhiindigloo.github.io/modelfinder-website/
Analytics: https://abhiindigloo.github.io/modelfinder-website/analytics.html
Support: https://abhiindigloo.github.io/modelfinder-website/support.html
Privacy: https://abhiindigloo.github.io/modelfinder-website/privacy.html
Terms: https://abhiindigloo.github.io/modelfinder-website/terms.html
Security: https://abhiindigloo.github.io/modelfinder-website/security.html

The website analytics preview is free. Paid analytics is intended but pricing, checkout, paid entitlement implementation, and commerce declarations remain incomplete. This ZIP is a preparation artifact, not a marketplace-approved release. The skills package does not embed website code or provide automatic account usage access.
